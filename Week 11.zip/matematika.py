phi = 3.14

def luas_lingkaran():
  jari_jari = float(input("Masukkan jari-jari lingkaran: "))
  return phi*jari_jari**2

def luas_persegi():
  sisi = float(input("Masukkan sisi persegi: "))
  return sisi**2